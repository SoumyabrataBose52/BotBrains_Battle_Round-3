from dronekit import connect, VehicleMode, LocationGlobalRelative
import time
import serial
from xbee import ZigBee, DigiMesh
import board
import busio
import adafruit_tcs34725
import pyrealsense2 as rs
import hashlib
import json
import threading
import numpy as np
import requests
from cryptography.fernet import Fernet
import RPi.GPIO as GPIO  # Import GPIO library


DRONE_ID = 1  # Change this to 2 for the second drone and 3 for the third drone

# Examples... Define the addresses of the other drones
DRONE_ADDRESSES = {
    1: b'\x00\x13\xa2\x00A\xbd\xf5\xec',
    2: b'\x00\x13\xa2\x00A\xbd\xf5\xed',
    3: b'\x00\x13\xa2\x00A\xbd\xf5\xee'
}

# Connect to the Vehicle
print("Connecting to vehicle...")
vehicle = connect('/dev/ttyAMA0', wait_ready=True, baud=57600)

# Setup Color Sensor
i2c = busio.I2C(board.SCL, board.SDA)
color_sensor = adafruit_tcs34725.TCS34725(i2c)
color_sensor.integration_time = 0xEB
color_sensor.gain = 0x01

# Setup Lidar Sensor
lidar_serial = serial.Serial("/dev/serial0", 115200, timeout=1)

# Setup XBee Communication
ser = serial.Serial('/dev/ttyUSB0', 9600)
xbee = DigiMesh(ser)

# Initialize RealSense pipeline
pipeline = rs.pipeline()
config = rs.config()
config.enable_stream(rs.stream.pose)
config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
pipeline.start(config)

# GPIO setup for rainfall sensor
RAIN_SENSOR_PIN = 17
GPIO.setmode(GPIO.BCM)
GPIO.setup(RAIN_SENSOR_PIN, GPIO.IN)

# Function to check rainfall
def is_raining():
    return GPIO.input(RAIN_SENSOR_PIN) == GPIO.LOW

# Function to check battery level
def check_battery_level():
    return vehicle.battery.voltage

# Generate a key for encryption
key = Fernet.generate_key()
cipher = Fernet(key)

# Initialize blockchain
class Blockchain:
    def __init__(self):
        self.chain = []
        self.current_transactions = []
        self.new_block(previous_hash='1', proof=100)

    def new_block(self, proof, previous_hash=None):
        block = {
            'index': len(self.chain) + 1,
            'timestamp': time.time(),
            'transactions': self.current_transactions,
            'proof': proof,
            'previous_hash': previous_hash or self.hash(self.chain[-1]),
        }
        self.current_transactions = []
        encrypted_block = self.encrypt_block(block)
        self.chain.append(encrypted_block)
        return encrypted_block

    def new_transaction(self, sender, recipient, amount):
        self.current_transactions.append({
            'sender': sender,
            'recipient': recipient,
            'amount': amount,
        })
        return self.last_block['index'] + 1

    @staticmethod
    def hash(block):
        block_string = json.dumps(block, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

    @property
    def last_block(self):
        return self.decrypt_block(self.chain[-1])

    def encrypt_block(self, block):
        block_string = json.dumps(block, sort_keys=True).encode()
        encrypted_block = cipher.encrypt(block_string)
        return encrypted_block

    def decrypt_block(self, encrypted_block):
        decrypted_block_string = cipher.decrypt(encrypted_block).decode()
        block = json.loads(decrypted_block_string)
        return block

blockchain = Blockchain()

# Define Target Color
TARGET_COLOR = (0, 255, 0)  # Green

# Function to measure object dimensions using Lidar
def measure_dimensions():
    lidar_serial.write(b'B')
    time.sleep(0.1)
    data = lidar_serial.readline().decode('utf-8')
    height = float(data.split(',')[0])
    width = float(data.split(',')[1])
    depth = float(data.split(',')[2])
    return height, width, depth

# Function to check if color is green
def is_color_green():
    r, g, b, _ = color_sensor.color_rgba
    return g > r and g > b

# Function to get SLAM data
def get_slam_data():
    frames = pipeline.wait_for_frames()
    pose = frames.get_pose_frame()
    if pose:
        data = pose.get_pose_data()
        position = data.translation
        return position.x, position.y, position.z
    return None, None, None

# Function to send target found message to other drones
def send_target_found():
    message = b"TARGET_FOUND"
    encrypted_message = cipher.encrypt(message)
    for drone_id, address in DRONE_ADDRESSES.items():
        if drone_id != DRONE_ID:
            xbee.send('tx', dest_addr=address, data=encrypted_message)

# XBee callback function
def xbee_callback(data):
    encrypted_message = data['rf_data']
    message = cipher.decrypt(encrypted_message)
    if message == b"TARGET_FOUND":
        print("Target found by another drone. Stopping search...")
        vehicle.mode = VehicleMode("LOITER")

# Setup XBee callback
xbee.register_callback(xbee_callback)

# Function to log data to blockchain
def log_to_blockchain(data):
    blockchain.new_transaction(sender="drone", recipient="network", amount=1)
    blockchain.new_block(proof=100)

# Function to send target location to user
def send_location_to_user(location_data):
    url = "Enter url of web server here"
    response = requests.post(url, json=location_data)
    if response.status_code == 200:
        print("Location sent to user successfully")
    else:
        print(f"Failed to send location to user: {response.status_code}")

# Emergency Landing Function
def emergency_land():
    print("Emergency landing initiated!")
    vehicle.mode = VehicleMode("LAND")
    while vehicle.armed:
        print(" Waiting for landing...")
        time.sleep(1)
    print("Landed successfully.")

# Health Check Function
def health_check():
    while True:
        try:
            # Rainfall check
            if is_raining():
                print("Rain detected! Initiating emergency landing.")
                emergency_land()
                break

            # Battery level check
            battery_voltage = check_battery_level()
            if battery_voltage < 10.5:  # Adjust the threshold as necessary
                print("Low battery! Initiating emergency landing.")
                emergency_land()
                break

            xbee.send('tx', data=b'HEALTH_CHECK')
            response = xbee.wait_read_frame()
            if response['id'] == 'tx_status' and response['deliver_status'] != '\x00':
                print("Health check failed, attempting to reconfigure network...")
                reconfigure_network()
            time.sleep(10)
        except Exception as e:
            print(f"Health check exception: {e}")
            emergency_land()
            break

# Function to reconfigure network
def reconfigure_network():
    try:
        print("Reconfiguring network...")
        #Re-initializing the XBee network
        xbee.halt()
        global ser
        ser.close()
        ser = serial.Serial('/dev/ttyUSB0', 9600)
        global xbee
        xbee = DigiMesh(ser)
        xbee.register_callback(xbee_callback)
        print("Network reconfiguration complete.")
    except Exception as e:
        print(f"Network reconfiguration failed: {e}")
        emergency_land()

# Start health check thread
health_thread = threading.Thread(target=health_check)
health_thread.daemon = True
health_thread.start()

# Function to detect obstacles using RealSense depth data
def detect_obstacles():
    frames = pipeline.wait_for_frames()
    depth_frame = frames.get_depth_frame()
    if not depth_frame:
        return None

    # Convert depth frame to numpy array
    depth_image = np.asanyarray(depth_frame.get_data())

    # Threshold depth image
    depth_threshold = 1.5  # Meters
    obstacle_detected = np.any(depth_image < depth_threshold)

    return obstacle_detected

# Function to avoid obstacles
def avoid_obstacle():
    print("Obstacle detected! Avoiding...")
    # Example avoidance maneuver: move up
    vehicle.simple_goto(LocationGlobalRelative(vehicle.location.global_relative_frame.lat,
                                               vehicle.location.global_relative_frame.lon,
                                               vehicle.location.global_relative_frame.alt + 2))
    time.sleep(2)  # Allow time for maneuver

# Function to handle received XBee messages with decryption
def xbee_callback(data):
    encrypted_message = data['rf_data']
    message = cipher.decrypt(encrypted_message)
    if message == b"TARGET_FOUND":
        print("Target found by another drone. Stopping search...")
        vehicle.mode = VehicleMode("LOITER")

# Setup XBee callback
xbee.register_callback(xbee_callback)

# Enhanced SLAM Function
def enhanced_slam():
    map_data = {}
    while True:
        x, y, z = get_slam_data()
        if x is not None and y is not None and z is not None:
            # Record the position in the map
            map_data[time.time()] = (x, y, z)
        time.sleep(0.5)  # Adjust the sleep time as needed
    return map_data

# Swarm intelligence to share map data with other drones
def share_map_data(map_data):
    map_data_json = json.dumps(map_data)
    encrypted_map_data = cipher.encrypt(map_data_json.encode())
    for drone_id, address in DRONE_ADDRESSES.items():
        if drone_id != DRONE_ID:
            xbee.send('tx', dest_addr=address, data=encrypted_map_data)

# Search function with obstacle detection, enhanced SLAM, and location reporting
def search_target():
    map_data = enhanced_slam()
    while True:
        try:
            # Perform flight pattern
            vehicle.simple_goto(LocationGlobalRelative(vehicle.location.global_relative_frame.lat + 0.0001,
                                                       vehicle.location.global_relative_frame.lon,
                                                       vehicle.location.global_relative_frame.alt))
            time.sleep(2)

            # Check for obstacles
            if detect_obstacles():
                avoid_obstacle()
                continue

            # Check for objects
            height, width, depth = measure_dimensions()
            if height == 15.0 and width == 15.0 and depth == 15.0:
                if is_color_green():
                    print("Target found!")
                    send_target_found()
                    x, y, z = get_slam_data()
                    location_data = {
                        "location": {"x": x, "y": y, "z": z},
                        "color": "green"
                    }
                    log_to_blockchain(location_data)
                    send_location_to_user(location_data)
                    vehicle.mode = VehicleMode("LOITER")
                    break

            # Share map data with other drones
            share_map_data(map_data)

            time.sleep(1)
        except Exception as e:
            print(f"Exception during search: {e}")
            emergency_land()
            break

# Arm and takeoff
def arm_and_takeoff(aTargetAltitude):
    try:
        print("Basic pre-arm checks")
        while not vehicle.is_armable:
            print(" Waiting for vehicle to initialise...")
            time.sleep(1)

        print("Arming motors")
        vehicle.mode = VehicleMode("GUIDED")
        vehicle.armed = True

        while not vehicle.armed:
            print(" Waiting for arming...")
            time.sleep(1)

        print("Taking off!")
        vehicle.simple_takeoff(aTargetAltitude)

        while True:
            print(" Altitude: ", vehicle.location.global_relative_frame.alt)
            if vehicle.location.global_relative_frame.alt >= aTargetAltitude * 0.95:
                print("Reached target altitude")
                break
            time.sleep(1)
    except Exception as e:
        print(f"Exception during takeoff: {e}")
        emergency_land()

# Main Function
def main():
    try:
        arm_and_takeoff(10)
        search_target()
    except Exception as e:
        print(f"Exception in main: {e}")
        emergency_land()
    finally:
        vehicle.mode = VehicleMode("LAND")

if __name__ == "__main__":
    main()
